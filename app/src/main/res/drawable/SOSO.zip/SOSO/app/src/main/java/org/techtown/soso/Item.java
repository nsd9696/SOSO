package org.techtown.soso;


public class Item {

    int imageid;

    public Item(int imageid) {
        this.imageid=imageid;
    }

}
